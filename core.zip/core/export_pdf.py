from fpdf import FPDF
from pathlib import Path
import datetime
import google.generativeai as genai
import json
import re
import textwrap
import unicodedata

DEFAULT_MODEL = "gemini-2.0-flash"

# ==================================================
# 🧹 Text Cleaning Utils
# ==================================================

def strip_emoji(text: str) -> str:
    """Remove emojis and zero-width spaces."""
    if not isinstance(text, str):
        return ""
    text = text.replace("\xa0", " ").replace("\u200b", "")
    emoji_pattern = re.compile("["
        u"\U0001F600-\U0001F64F"
        u"\U0001F300-\U0001F5FF"
        u"\U0001F680-\U0001F6FF"
        u"\U0001F1E0-\U0001F1FF"
        u"\U00002700-\U000027BF"
        u"\U0001F900-\U0001F9FF"
        u"\u200b"
        "]+", flags=re.UNICODE)
    return emoji_pattern.sub("", text)

def _safe_text(s: str) -> str:
    """Clean text for PDF: remove emojis, URLs, markdown, and unsafe Unicode."""
    if not isinstance(s, str):
        return ""

    # Normalize Unicode (remove accent composition)
    s = unicodedata.normalize("NFKD", s)
    s = "".join(ch for ch in s if not unicodedata.combining(ch))

    # Remove emojis, invisible chars, etc.
    s = re.sub(r"[\u0000-\u001F\u007F-\u009F]", "", s)
    s = re.sub(r"[\u200B-\u206F\ufeff\ufe0f]", "", s)
    s = re.sub(r"[\U0001F000-\U0001FAFF]", "", s)
    s = re.sub(r"[\u2600-\u26FF\u2700-\u27BF]", "", s)

    # 🧨 Remove URLs (http, https, www)
    s = re.sub(r"http\S+", "", s)
    s = re.sub(r"www\.\S+", "", s)

    # Remove markdown symbols
    s = re.sub(r"[*_`#>\[\]\(\)\"“”‘’•]+", "", s)

    # Remove non-ASCII or odd punctuation
    s = re.sub(r"[^\x20-\x7E]", " ", s)

    # 🔥 Force break long unspaced words (prevent width errors)
    tokens = []
    for word in s.split():
        if len(word) > 50:
            parts = [word[i:i+50] for i in range(0, len(word), 50)]
            tokens.extend(parts)
        else:
            tokens.append(word)
    s = " ".join(tokens)

    # Trim and collapse
    s = re.sub(r"\s+", " ", s).strip()

    if len(s) > 1000:
        s = s[:1000] + "..."
    return s


# ==================================================
# 🧱 Safe Wrappers (auto line break)
# ==================================================

def safe_multicell(pdf: FPDF, w, h, text, **kwargs):
    """Render text safely with enforced wrapping."""
    try:
        text = _safe_text(text or "")
        if not text.strip():
            return

        # compute effective available width in current units (mm for default)
        try:
            if w and float(w) > 0:
                eff_w = float(w)
            else:
                eff_w = pdf.w - pdf.r_margin - pdf.l_margin - pdf.x
        except Exception:
            eff_w = pdf.w - pdf.r_margin - pdf.l_margin

        # ensure we have a sane positive width
        if eff_w <= 1:
            eff_w = max(20, pdf.w - pdf.r_margin - pdf.l_margin)

        # estimate characters per line using current font average width
        try:
            avg_char_w = pdf.get_string_width("M") or 1.0
            chars_per_line = max(20, int(eff_w / avg_char_w))
        except Exception:
            chars_per_line = 85

        # Wrap using computed chars per line and force-breaking long words
        wrapped_lines = textwrap.wrap(
            text,
            width=chars_per_line,
            break_long_words=True,
            break_on_hyphens=False,
        )
        for line in wrapped_lines:
            try:
                pdf.multi_cell(eff_w, h, line, **kwargs)
            except Exception as e:
                # last-resort: try with default full width (0) or skip
                try:
                    pdf.multi_cell(0, h, line, **kwargs)
                except Exception:
                    print(f"[WARN] Skip text due to PDF rendering error: {e}")
    except Exception as e:
        print(f"[WARN] Skip text due to PDF rendering error: {e}")


def safe_cell(pdf: FPDF, w, h, text, **kwargs):
    """Render one line safely, fallback to multicell if too long."""
    try:
        text = _safe_text(text or "")
        # compute effective width (as in safe_multicell)
        try:
            if w and float(w) > 0:
                eff_w = float(w)
            else:
                eff_w = pdf.w - pdf.r_margin - pdf.l_margin - pdf.x
        except Exception:
            eff_w = pdf.w - pdf.r_margin - pdf.l_margin

        # estimate chars per line
        try:
            avg_char_w = pdf.get_string_width("M") or 1.0
            chars_per_line = max(20, int(eff_w / avg_char_w))
        except Exception:
            chars_per_line = 80

        if len(text) > chars_per_line:
            safe_multicell(pdf, eff_w, h, text, **kwargs)
        else:
            try:
                pdf.cell(w, h, text, **kwargs)
            except Exception:
                # fallback to cell with effective width
                pdf.cell(eff_w, h, text, **kwargs)
    except Exception as e:
        print(f"[WARN] Skip text due to PDF rendering error: {e}")

# ==================================================
# 🤖 Gemini Helpers
# ==================================================

def summarize_day_parts(day_data, model_name=DEFAULT_MODEL):
    """Use Gemini to divide POIs logically by time of day."""
    prompt = f"""
You are an expert travel planner.
Divide this list of POIs by time of day (morning, noon, afternoon, evening).

Return **only valid JSON**, no explanation or markdown.
Input POIs: {day_data}
"""
    try:
        model = genai.GenerativeModel(model_name)
        resp = model.generate_content(prompt)
        return json.loads(resp.text.strip())
    except Exception:
        return {"morning": [], "noon": [], "afternoon": [], "evening": []}

def translate_to_english(text, model_name=DEFAULT_MODEL):
    """Translate Vietnamese or mixed-language text into clean English."""
    if not text or not isinstance(text, str):
        return ""
    text = strip_emoji(text)
    prompt = f"""
Translate the following text to concise, fluent English.
Return only the translated result, no explanation or markdown.

Text:
{text}
"""
    try:
        model = genai.GenerativeModel(model_name)
        resp = model.generate_content(prompt)
        return _safe_text(resp.text.strip())
    except Exception:
        return _safe_text(text)

# ==================================================
# 📄 Main PDF Export
# ==================================================

def export_itinerary_to_pdf(out_days, filename="itinerary.pdf"):
    """
    Export a generated itinerary to a clean, English PDF.
    Includes daily sections, time-of-day breakdown, and POI details.
    """
    pdf = FPDF(format="A4")
    pdf.add_page()
    pdf.set_left_margin(15)
    pdf.set_right_margin(15)

    fonts_dir = Path("fonts")
    pdf.add_font("Noto", "", str(fonts_dir / "NotoSans-Regular.ttf"), uni=True)
    pdf.add_font("Noto", "B", str(fonts_dir / "NotoSans-Bold.ttf"), uni=True)
    pdf.add_font("Noto", "I", str(fonts_dir / "NotoSans-Italic.ttf"), uni=True)

    # Header
    pdf.set_font("Noto", "B", 18)
    safe_multicell(pdf, 0, 12, "TravelGPT+ Smart Itinerary (English Version)", align="C")
    pdf.set_font("Noto", "", 12)
    pdf.cell(0, 10, f"Generated on: {datetime.datetime.now().strftime('%Y-%m-%d')}", ln=True, align="C")
    pdf.ln(8)

    # Each day
    for day_index, day in enumerate(out_days, start=1):
        title = translate_to_english(day.get("title", f"Day {day_index}"))
        weather = translate_to_english(day.get("weather", ""))
        total_distance = day.get("distance", 0.0)
        pois = day.get("pois", [])

        pdf.set_font("Noto", "B", 15)
        safe_multicell(pdf, 0, 10, f"Day {day_index}: {title}", align="L")
        pdf.set_font("Noto", "I", 11)

        if weather:
            safe_multicell(pdf, 0, 8, f"Weather: {weather}", align="L")
        safe_multicell(pdf, 0, 8, f"Total distance: {float(total_distance):.2f} km", align="L")
        pdf.ln(4)

        # Split POIs into morning, noon, etc.
        summary = summarize_day_parts(json.dumps([p["name"] for p in pois], ensure_ascii=False))
        slots = [
            ("Morning", summary.get("morning", [])),
            ("Noon", summary.get("noon", [])),
            ("Afternoon", summary.get("afternoon", [])),
            ("Evening", summary.get("evening", [])),
        ]

        # helper to normalize names for robust matching (strip accents, lower)
        def _norm(s: str) -> str:
            if not isinstance(s, str):
                return ""
            s = unicodedata.normalize("NFKD", s)
            s = "".join(ch for ch in s if not unicodedata.combining(ch))
            s = re.sub(r"[^a-zA-Z0-9 ]", "", s)
            return s.strip().lower()

        # build normalized slot name sets for matching
        slot_norm_sets = []
        any_slot_nonempty = False
        for _, slot_pois in slots:
            norm_set = set(_norm(n) for n in slot_pois if n)
            slot_norm_sets.append(norm_set)
            if norm_set:
                any_slot_nonempty = True

        # If Gemini returned no slots (empty), fallback to rendering all POIs in order
        if not any_slot_nonempty:
            pdf.set_font("Noto", "B", 13)
            safe_multicell(pdf, 0, 8, "Full day POIs", align="L")
            pdf.set_font("Noto", "", 11)
            for p in pois:
                _render_poi_block(pdf, p)
        else:
            # Render each non-empty slot and match POIs robustly
            for idx, (slot_name, slot_pois) in enumerate(slots):
                norm_set = slot_norm_sets[idx]
                if not norm_set:
                    continue
                pdf.set_font("Noto", "B", 13)
                safe_multicell(pdf, 0, 8, f"{slot_name}", align="L")
                pdf.set_font("Noto", "", 11)
                for p in pois:
                    name_raw = p.get("name", "")
                    name_trans = translate_to_english(name_raw)
                    if _norm(name_raw) in norm_set or _norm(name_trans) in norm_set:
                        _render_poi_block(pdf, p)
                pdf.ln(3)

        pdf.ln(8)

    # Footer
    pdf.set_y(-20)
    pdf.set_font("Noto", "I", 9)
    safe_multicell(pdf, 0, 10, "Generated automatically by TravelGPT+", align="C")

    out_path = Path(filename)
    pdf.output(str(out_path))
    return str(out_path)

# ==================================================
# 🏙️ POI Renderer
# ==================================================

def _render_poi_block(pdf: FPDF, p: dict):
    """Render one POI safely with name, rating, cost, tag, address, description."""
    name = translate_to_english(p.get("name", "Unnamed location"))
    desc = translate_to_english(p.get("description", ""))
    address = translate_to_english(p.get("address", ""))
    rating = p.get("rating")
    cost = p.get("avg_cost")
    tag = translate_to_english(p.get("tag", ""))

    pdf.set_font("Noto", "B", 12)
    safe_multicell(pdf, 0, 7, name, align="L")
    pdf.set_font("Noto", "", 11)

    info_parts = []
    if rating:
        info_parts.append(f"⭐ Rating: {rating}")
    if cost:
        try:
            info_parts.append(f"💵 Avg cost: {int(cost):,} VND")
        except:
            pass
    if tag:
        info_parts.append(f"🏷️ Tags: {tag}")

    if info_parts:
        safe_multicell(pdf, 0, 7, " | ".join(info_parts), align="L")
    if address:
        safe_multicell(pdf, 0, 7, f"📍 Address: {address}", align="L")
    if desc:
        safe_multicell(pdf, 0, 6, desc, align="L")
    pdf.ln(4)
